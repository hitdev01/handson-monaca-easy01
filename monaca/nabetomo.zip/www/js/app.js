// This is a JavaScript file

// module
var myApp = angular.module('myApp', []);

